import flaskr

application = app = flaskr.create_app()


if __name__ == '__main__':
    app.run()
